			<!-- Sidebar -->
			<div class="col-xs-6 col-sm-3 sidebar-offcanvas" id="sidebar">
				<div class="panel panel-primary">
					<div class="panel-heading">Les 5 films les mieux notés</div>
					<div class="list-group">
						<a href="#" class="list-group-item">Link</a>
						<a href="#" class="list-group-item">Link</a>
						<a href="#" class="list-group-item">Link</a>
						<a href="#" class="list-group-item">Link</a>
						<a href="#" class="list-group-item">Link</a>
					</div>
				</div>

				<div class="panel panel-default">
					<div class="panel-heading">Les 5 films les plus récents</div>
					<div class="list-group">
						<a href="#" class="list-group-item">Link</a>
						<a href="#" class="list-group-item">Link</a>
						<a href="#" class="list-group-item">Link</a>
						<a href="#" class="list-group-item">Link</a>
						<a href="#" class="list-group-item">Link</a>
					</div>
				</div>

				<div class="panel panel-default">
					<div class="panel-heading">Les dernières actualités</div>
					<div class="panel-body">
						...
					</div>
				</div>
			</div>
			<!-- End Sidebar -->