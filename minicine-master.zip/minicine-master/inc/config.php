<?php

$pages = array(
	'index.php' => 'Accueil',
	'news.php' => 'Actualités',
	'search.php' => 'Recherche',
	'contact.php' => 'Contact',
);

$current_page = basename($_SERVER['PHP_SELF']);